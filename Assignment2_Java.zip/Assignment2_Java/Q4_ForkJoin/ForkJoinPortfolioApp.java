import java.util.Random;
import java.util.concurrent.ForkJoinPool;

public class ForkJoinPortfolioApp {

    static double serialSum(double[] data) {
        double sum = 0;
        for (double v : data) {
            sum += v;
        }
        return sum;
    }

    static double[] generate(int size, long seed) {
        Random random = new Random(seed);
        double[] data = new double[size];
        for (int i = 0; i < size; i++) {
            data[i] = 10 + random.nextDouble() * 990;   // 10.00 .. 1000.00
        }
        return data;
    }

    // Average time (ms) of serial vs parallel summation over 'runs' repetitions
    static double[] timeBoth(double[] data, ForkJoinPool pool, int runs) {
        double sink = 0;
        long serialTotal = 0, parallelTotal = 0;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            sink += serialSum(data);
            serialTotal += System.nanoTime() - t0;

            long t1 = System.nanoTime();
            sink += pool.invoke(new ParallelRiskCalculator(data, 0, data.length));
            parallelTotal += System.nanoTime() - t1;
        }
        if (sink == 42) System.out.print("");   // keep JIT from discarding the work
        return new double[] { serialTotal / 1e6 / runs, parallelTotal / 1e6 / runs };
    }

    public static void main(String[] args) {

        final int SIZE = 10_000;
        final double RISK_CAP = 800.0;

        double[] assets = generate(SIZE, 247198L);
        ForkJoinPool pool = new ForkJoinPool();

        System.out.println("==========================================");
        System.out.println("  FORK/JOIN PARALLEL PORTFOLIO ENGINE");
        System.out.println("==========================================");
        System.out.println("Asset array size    : " + SIZE);
        System.out.println("Available cores     : " + Runtime.getRuntime().availableProcessors());
        System.out.println("Sequential THRESHOLD: 1000");
        System.out.println("------------------------------------------");

        // ---- Task 1: cumulative risk score (RecursiveTask) ----
        long s0 = System.nanoTime();
        double serialRisk = serialSum(assets);
        long serialNs = System.nanoTime() - s0;

        long p0 = System.nanoTime();
        double parallelRisk = pool.invoke(new ParallelRiskCalculator(assets, 0, SIZE));
        long parallelNs = System.nanoTime() - p0;

        System.out.printf("Serial risk score   : %.2f%n", serialRisk);
        System.out.printf("Parallel risk score : %.2f%n", parallelRisk);
        System.out.println("Scores match        : " + (Math.abs(serialRisk - parallelRisk) < 1e-6));
        System.out.printf("Single-run serial   : %.4f ms%n", serialNs / 1e6);
        System.out.printf("Single-run parallel : %.4f ms (includes pool start-up)%n", parallelNs / 1e6);
        System.out.println("------------------------------------------");

        // ---- Task 2: stress-test penalty (RecursiveAction) ----
        int before = 0;
        for (double v : assets) if (v > RISK_CAP) before++;

        long a0 = System.nanoTime();
        pool.invoke(new PortfolioThresholdTask(assets, 0, SIZE, RISK_CAP));
        long adjustNs = System.nanoTime() - a0;

        double stressedRisk = pool.invoke(new ParallelRiskCalculator(assets, 0, SIZE));

        System.out.println("Risk cap            : " + RISK_CAP);
        System.out.println("Assets above cap    : " + before);
        System.out.printf("Stress-test time    : %.4f ms%n", adjustNs / 1e6);
        System.out.printf("Risk after +5%% test : %.2f%n", stressedRisk);
        System.out.printf("Risk increase       : %.2f (%.2f%%)%n",
                stressedRisk - parallelRisk, (stressedRisk - parallelRisk) / parallelRisk * 100);
        System.out.println("------------------------------------------");

        // ---- Warmed-up benchmark, 10,000 elements ----
        timeBoth(assets, pool, 200);                       // JIT warm-up
        double[] t = timeBoth(assets, pool, 2000);
        System.out.println("Benchmark (10,000 elements, average of 2000 runs after warm-up)");
        System.out.printf("  Serial   : %.5f ms%n", t[0]);
        System.out.printf("  Parallel : %.5f ms%n", t[1]);
        System.out.printf("  Speedup  : %.2fx%n", t[0] / t[1]);
        System.out.println("------------------------------------------");

        // ---- Larger dataset to show real parallel speedup ----
        double[] big = generate(20_000_000, 1L);
        timeBoth(big, pool, 3);                            // warm-up
        double[] tb = timeBoth(big, pool, 10);
        System.out.println("Benchmark (20,000,000 elements, average of 10 runs)");
        System.out.printf("  Serial   : %.3f ms%n", tb[0]);
        System.out.printf("  Parallel : %.3f ms%n", tb[1]);
        System.out.printf("  Speedup  : %.2fx%n", tb[0] / tb[1]);
        System.out.println("==========================================");

        pool.shutdown();
    }
}
