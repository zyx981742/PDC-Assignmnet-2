import java.util.concurrent.RecursiveAction;

public class PortfolioThresholdTask extends RecursiveAction {

    private static final int THRESHOLD = 1000;
    private static final double STRESS_PENALTY = 1.05; // +5% volatility penalty

    private final double[] assetValues;
    private final int start;
    private final int end;
    private final double riskCap;

    public PortfolioThresholdTask(double[] assetValues, int start, int end, double riskCap) {
        this.assetValues = assetValues;
        this.start = start;
        this.end = end;
        this.riskCap = riskCap;
    }

    @Override
    protected void compute() {
        int length = end - start;

        if (length <= THRESHOLD) {
            // In-place adjustment of every value that exceeds the risk cap
            for (int i = start; i < end; i++) {
                if (assetValues[i] > riskCap) {
                    assetValues[i] = assetValues[i] * STRESS_PENALTY;
                }
            }
            return;
        }

        int mid = start + length / 2;
        PortfolioThresholdTask left  = new PortfolioThresholdTask(assetValues, start, mid, riskCap);
        PortfolioThresholdTask right = new PortfolioThresholdTask(assetValues, mid, end, riskCap);

        left.fork();
        right.compute();
        left.join();
    }
}
