import java.util.concurrent.RecursiveTask;

public class ParallelRiskCalculator extends RecursiveTask<Double> {

    private static final int THRESHOLD = 1000;

    private final double[] assetValues;
    private final int start;
    private final int end;

    public ParallelRiskCalculator(double[] assetValues, int start, int end) {
        this.assetValues = assetValues;
        this.start = start;
        this.end = end;
    }

    @Override
    protected Double compute() {
        int length = end - start;

        // Small segment: compute the sum sequentially
        if (length <= THRESHOLD) {
            double sum = 0;
            for (int i = start; i < end; i++) {
                sum += assetValues[i];
            }
            return sum;
        }

        // Large segment: split into two sub-tasks
        int mid = start + length / 2;
        ParallelRiskCalculator left  = new ParallelRiskCalculator(assetValues, start, mid);
        ParallelRiskCalculator right = new ParallelRiskCalculator(assetValues, mid, end);

        left.fork();                       // run left asynchronously
        double rightResult = right.compute(); // compute right in this thread
        double leftResult = left.join();   // wait for left result

        return leftResult + rightResult;
    }
}
