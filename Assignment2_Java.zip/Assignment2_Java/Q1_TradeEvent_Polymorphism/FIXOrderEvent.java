public class FIXOrderEvent extends TradeEvent {

    private static final double EXCHANGE_FEE_RATE = 0.0015; // 0.15%

    private String clOrdId;
    private int quantity;

    public FIXOrderEvent(String senderId, long timestamp, double basePrice,
                         String clOrdId, int quantity) {
        super(senderId, timestamp, basePrice);
        this.clOrdId = clOrdId;
        this.quantity = quantity;
    }

    @Override
    public void dispatch() {
        double orderValue = basePrice * quantity;
        double fee = orderValue * EXCHANGE_FEE_RATE;
        double totalCost = orderValue + fee;

        System.out.println("FIX Stock Purchase Order");
        System.out.println("Sender ID        : " + senderId);
        System.out.println("Timestamp        : " + timestamp);
        System.out.println("ClOrdID          : " + clOrdId);
        System.out.println("Quantity         : " + quantity + " shares");
        System.out.printf("Price per share  : %.2f%n", basePrice);
        System.out.printf("Order value      : %.2f%n", orderValue);
        System.out.printf("Exchange fee 0.15%%: %.2f%n", fee);
        System.out.printf("Total cost       : %.2f%n", totalCost);
        System.out.println("Status           : ORDER EXECUTED");
    }
}
