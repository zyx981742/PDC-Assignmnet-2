public class TradingEngineApp {

    public static void main(String[] args) {

        // Subclass objects stored in SUPERCLASS reference variables
        TradeEvent event1 = new FIXOrderEvent(
                "FIX-GATEWAY-01", 1761300000000L, 185.50, "ORD-90001", 100);

        TradeEvent event2 = new ReutersQuoteEvent(
                "REUTERS-FEED-07", 1761300000450L, 185.55, 185.48, 185.62);

        TradeEvent event3 = new TradeEvent(
                "GENERIC-SOURCE", 1761300000900L, 100.00);

        TradeEvent[] events = { event1, event2, event3 };

        System.out.println("==========================================");
        System.out.println("   COMPLEX EVENT PROCESSING (CEP) ENGINE");
        System.out.println("==========================================");

        for (TradeEvent event : events) {
            // Runtime polymorphism: JVM picks the overridden dispatch()
            event.dispatch();
            System.out.println("------------------------------------------");
        }

        System.out.println("      ALL EVENTS DISPATCHED SUCCESSFULLY");
        System.out.println("==========================================");
    }
}
