public class ReutersQuoteEvent extends TradeEvent {

    private double bidPrice;
    private double askPrice;

    public ReutersQuoteEvent(String senderId, long timestamp, double basePrice,
                             double bidPrice, double askPrice) {
        super(senderId, timestamp, basePrice);
        this.bidPrice = bidPrice;
        this.askPrice = askPrice;
    }

    @Override
    public void dispatch() {
        double spread = askPrice - bidPrice;
        double midPrice = (askPrice + bidPrice) / 2.0;
        double spreadPercent = (spread / midPrice) * 100.0;

        System.out.println("Reuters Real-Time Quote");
        System.out.println("Sender ID     : " + senderId);
        System.out.println("Timestamp     : " + timestamp);
        System.out.printf("Reference     : %.2f%n", basePrice);
        System.out.printf("Bid Price     : %.2f%n", bidPrice);
        System.out.printf("Ask Price     : %.2f%n", askPrice);
        System.out.printf("Bid-Ask Spread: %.2f%n", spread);
        System.out.printf("Mid Price     : %.3f%n", midPrice);
        System.out.printf("Spread %%      : %.4f%%%n", spreadPercent);
    }
}
