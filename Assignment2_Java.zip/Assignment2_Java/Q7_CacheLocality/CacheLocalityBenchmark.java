public class CacheLocalityBenchmark {

    private static final int N = 2000;
    private static final int ITERATIONS = 10;

    private static double[][] matrix = new double[N][N];

    // Row-major: inner loop walks along a row (contiguous memory, stride 1)
    public static double traverseRowMajor() {
        double sum = 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                sum += matrix[i][j];
            }
        }
        return sum;
    }

    // Column-major: inner loop jumps down a column (a different row array every step)
    public static double traverseColumnMajor() {
        double sum = 0;
        for (int j = 0; j < N; j++) {
            for (int i = 0; i < N; i++) {
                sum += matrix[i][j];
            }
        }
        return sum;
    }

    public static void main(String[] args) {

        // Fill the 2000 x 2000 matrix
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                matrix[i][j] = (i * 31 + j * 17) % 100 / 10.0;
            }
        }

        // JIT warm-up (not timed)
        double checksum = 0;
        for (int w = 0; w < 3; w++) {
            checksum += traverseRowMajor();
            checksum += traverseColumnMajor();
        }

        double[] rowTimes = new double[ITERATIONS];
        double[] colTimes = new double[ITERATIONS];
        double rowTotal = 0, colTotal = 0;

        System.out.println("==========================================");
        System.out.println("     CACHE LOCALITY BENCHMARK (2000 x 2000)");
        System.out.println("==========================================");
        System.out.println("Iteration | Row-Major (ms) | Column-Major (ms)");
        System.out.println("------------------------------------------");

        for (int it = 0; it < ITERATIONS; it++) {
            long t0 = System.nanoTime();
            double r = traverseRowMajor();
            long t1 = System.nanoTime();
            double c = traverseColumnMajor();
            long t2 = System.nanoTime();

            checksum += r + c;
            rowTimes[it] = (t1 - t0) / 1e6;
            colTimes[it] = (t2 - t1) / 1e6;
            rowTotal += rowTimes[it];
            colTotal += colTimes[it];

            System.out.printf("%9d | %14.3f | %17.3f%n", it + 1, rowTimes[it], colTimes[it]);
        }

        double rowAvg = rowTotal / ITERATIONS;
        double colAvg = colTotal / ITERATIONS;

        System.out.println("------------------------------------------");
        System.out.printf("Average Row-Major time    : %.3f ms%n", rowAvg);
        System.out.printf("Average Column-Major time : %.3f ms%n", colAvg);
        System.out.printf("Speedup (Column / Row)    : %.2fx%n", colAvg / rowAvg);
        System.out.println("Checksum (prevents dead-code removal): " + checksum);
        System.out.println("==========================================");
    }
}
