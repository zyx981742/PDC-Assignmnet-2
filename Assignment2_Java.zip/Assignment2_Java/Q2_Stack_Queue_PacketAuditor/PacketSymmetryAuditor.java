public class PacketSymmetryAuditor {

    // Returns true when the payload reads the same forwards and backwards
    public static boolean verifySymmetry(String payload) {

        TransactionStack stack = new TransactionStack(payload.length());
        RequestQueue queue = new RequestQueue(payload.length());

        System.out.println("Ingesting packet : " + payload);

        // Push into the LIFO stack while enqueueing into the FIFO queue
        for (int i = 0; i < payload.length(); i++) {
            char c = payload.charAt(i);
            stack.push(c);
            queue.enqueue(c);
        }

        boolean symmetric = true;
        int position = 1;

        // Pop (reverse order) and dequeue (original order) together
        while (!stack.isEmpty() && !queue.isEmpty()) {
            char fromStack = stack.pop();
            char fromQueue = queue.dequeue();

            String result = (fromStack == fromQueue) ? "MATCH" : "MISMATCH";
            System.out.println("  Step " + position + ": pop = '" + fromStack
                    + "'  dequeue = '" + fromQueue + "'  -> " + result);

            if (fromStack != fromQueue) {
                symmetric = false;
            }
            position++;
        }
        return symmetric;
    }

    public static void main(String[] args) {

        String[] packets = { "A1B2B1A", "level", "X9Y8Z7", "racecar" };

        System.out.println("==========================================");
        System.out.println("      PACKET SYMMETRY VERIFICATION LOG");
        System.out.println("==========================================");

        for (String packet : packets) {
            boolean symmetric = verifySymmetry(packet);
            System.out.println("Result : " + packet + " -> "
                    + (symmetric ? "SYMMETRIC (Palindrome signature detected)"
                                 : "NOT SYMMETRIC"));
            System.out.println("------------------------------------------");
        }

        System.out.println("          AUDIT COMPLETE");
        System.out.println("==========================================");
    }
}
