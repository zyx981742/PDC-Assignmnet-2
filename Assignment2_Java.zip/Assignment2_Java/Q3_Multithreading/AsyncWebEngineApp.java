public class AsyncWebEngineApp {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("Main thread: " + Thread.currentThread().getName());

        // Thread created by extending Thread
        TelemetryThread telemetry = new TelemetryThread();
        telemetry.setName("Telemetry-Worker");

        // Thread created by passing a Runnable into a new Thread object
        LogProcessorTask logTask = new LogProcessorTask();
        Thread logThread = new Thread(logTask);
        logThread.setName("Log-Worker");

        System.out.println("Telemetry-Worker state before start(): " + telemetry.getState());
        System.out.println("Log-Worker state before start()      : " + logThread.getState());

        // Start both threads so they run concurrently
        telemetry.start();
        logThread.start();

        System.out.println("Active threads started.");
        System.out.println("Telemetry-Worker alive: " + telemetry.isAlive());
        System.out.println("Log-Worker alive      : " + logThread.isAlive());

        // Main waits for both workers to finish before terminating
        telemetry.join();
        logThread.join();

        System.out.println("Both worker threads completed. Main thread exiting.");
    }
}
