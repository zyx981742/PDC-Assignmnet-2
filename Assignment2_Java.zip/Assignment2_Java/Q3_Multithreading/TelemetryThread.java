public class TelemetryThread extends Thread {

    @Override
    public void run() {
        Runtime runtime = Runtime.getRuntime();

        for (int i = 1; i <= 5; i++) {
            long usedMemoryMB = (runtime.totalMemory() - runtime.freeMemory())
                                / (1024 * 1024);
            int cpuCores = runtime.availableProcessors();

            System.out.println(
                Thread.currentThread().getName()
                + " - System health update: " + i
                + " | CPU cores: " + cpuCores
                + " | Memory used: " + usedMemoryMB + " MB"
            );

            try {
                Thread.sleep(800);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}
