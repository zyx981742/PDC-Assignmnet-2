import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

public class InventoryCatalogManager {

    private static final int PRODUCTS       = 1000;
    private static final int INITIAL_STOCK  = 1_000_000;
    private static final int WORKER_THREADS = 10;
    private static final int TOTAL_OPS      = 50_000;
    private static final int OPS_PER_THREAD = TOTAL_OPS / WORKER_THREADS;

    // Populate a catalog: productId -> stockCount
    private static void fill(Map<String, Integer> catalog) {
        for (int i = 0; i < PRODUCTS; i++) {
            catalog.put("PROD-" + i, INITIAL_STOCK);
        }
    }

    // Runs 10 workers; each does lookups and stock updates. Returns elapsed nanoseconds.
    private static long runWorkload(Map<String, Integer> catalog, AtomicLong updates)
            throws InterruptedException {

        ExecutorService pool = Executors.newFixedThreadPool(WORKER_THREADS);
        long start = System.nanoTime();

        for (int t = 0; t < WORKER_THREADS; t++) {
            final int seed = t;
            pool.submit(() -> {
                java.util.Random rnd = new java.util.Random(seed);
                for (int op = 0; op < OPS_PER_THREAD; op++) {
                    String id = "PROD-" + rnd.nextInt(PRODUCTS);
                    if (op % 2 == 0) {
                        catalog.get(id);                        // stock lookup
                    } else {
                        catalog.merge(id, -1, Integer::sum);    // atomic stock update
                        updates.incrementAndGet();
                    }
                }
            });
        }

        pool.shutdown();
        pool.awaitTermination(1, TimeUnit.MINUTES);
        return System.nanoTime() - start;
    }

    private static long totalStock(Map<String, Integer> catalog) {
        long sum = 0;
        for (int v : catalog.values()) sum += v;
        return sum;
    }

    private static void report(String name, Map<String, Integer> catalog,
                               long nanos, long updates) {
        double ms = nanos / 1e6;
        double throughput = TOTAL_OPS / (nanos / 1e9);
        long expected = (long) PRODUCTS * INITIAL_STOCK - updates;
        System.out.println("Collection     : " + name);
        System.out.printf("Execution time : %.3f ms%n", ms);
        System.out.printf("Throughput     : %,.0f operations/second%n", throughput);
        System.out.println("Data integrity : "
                + (totalStock(catalog) == expected ? "PASSED (no lost updates)" : "FAILED"));
    }

    public static void benchmarkSynchronizedMap() throws InterruptedException {
        Map<String, Integer> catalog = Collections.synchronizedMap(new HashMap<>());
        fill(catalog);
        AtomicLong updates = new AtomicLong();
        long nanos = runWorkload(catalog, updates);
        report("Collections.synchronizedMap(HashMap)", catalog, nanos, updates.get());
    }

    public static void benchmarkConcurrentMap() throws InterruptedException {
        Map<String, Integer> catalog = new ConcurrentHashMap<>();
        fill(catalog);
        AtomicLong updates = new AtomicLong();
        long nanos = runWorkload(catalog, updates);
        report("ConcurrentHashMap", catalog, nanos, updates.get());
    }

    public static void main(String[] args) throws InterruptedException {

        // Warm-up so the JIT compiler does not distort the first measurement
        for (int i = 0; i < 5; i++) {
            runWorkload(Collections.synchronizedMap(prefilled()), new AtomicLong());
            runWorkload(prefilled(new ConcurrentHashMap<>()), new AtomicLong());
        }

        System.out.println("==========================================");
        System.out.println("  INVENTORY CATALOG CONCURRENCY BENCHMARK");
        System.out.println("==========================================");
        System.out.println("Products       : " + PRODUCTS);
        System.out.println("Worker threads : " + WORKER_THREADS);
        System.out.println("Total ops      : " + TOTAL_OPS + " (lookups + updates)");
        System.out.println("------------------------------------------");

        benchmarkSynchronizedMap();
        System.out.println("------------------------------------------");
        benchmarkConcurrentMap();
        System.out.println("==========================================");
    }

    private static Map<String, Integer> prefilled() {
        return prefilled(new HashMap<>());
    }

    private static Map<String, Integer> prefilled(Map<String, Integer> map) {
        fill(map);
        return map;
    }
}
