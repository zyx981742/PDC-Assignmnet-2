import java.util.Random;

public class SensorGridMonitorApp {

    public static void main(String[] args) throws InterruptedException {

        final int SIZE = 50_000;
        final int WORKERS = 4;

        // Synthetic telemetry readings between 20.0 and 120.0
        Random random = new Random(247198L);
        double[] sensorData = new double[SIZE];
        for (int i = 0; i < SIZE; i++) {
            sensorData[i] = 20 + random.nextDouble() * 100;
        }

        // Plant known extremes so the result can be verified
        sensorData[12_345] = 3.75;     // critical low temperature
        sensorData[41_999] = 187.60;   // peak vibration spike

        ParallelMinSearch minSearch = new ParallelMinSearch(sensorData, 0, SIZE, WORKERS);
        ParallelMaxSearch maxSearch = new ParallelMaxSearch(sensorData, 0, SIZE, WORKERS);

        System.out.println("==========================================");
        System.out.println("     IoT SENSOR GRID MONITOR");
        System.out.println("==========================================");
        System.out.println("Sensor readings : " + SIZE);
        System.out.println("Workers per scan: " + WORKERS);
        System.out.println("------------------------------------------");

        // Run the MIN and MAX reductions simultaneously
        Thread minRunner = new Thread(() -> {
            try { minSearch.processGrid(); } catch (InterruptedException e) { }
        }, "Min-Engine");
        Thread maxRunner = new Thread(() -> {
            try { maxSearch.processGrid(); } catch (InterruptedException e) { }
        }, "Max-Engine");

        long start = System.nanoTime();
        minRunner.start();
        maxRunner.start();
        minRunner.join();
        maxRunner.join();
        long parallelNs = System.nanoTime() - start;

        System.out.println("------------------------------------------");
        System.out.printf("Global critical MIN temperature : %.2f%n", minSearch.getGlobalMin());
        System.out.printf("Global critical MAX vibration   : %.2f%n", maxSearch.getGlobalMax());
        System.out.println("------------------------------------------");

        // Serial check for correctness and timing comparison
        long s0 = System.nanoTime();
        double sMin = Double.MAX_VALUE, sMax = -Double.MAX_VALUE;
        for (double v : sensorData) {
            if (v < sMin) sMin = v;
            if (v > sMax) sMax = v;
        }
        long serialNs = System.nanoTime() - s0;

        System.out.println("Verification vs serial scan     : "
                + ((sMin == minSearch.getGlobalMin() && sMax == maxSearch.getGlobalMax())
                        ? "PASSED" : "FAILED"));
        System.out.printf("Parallel execution time : %.3f ms%n", parallelNs / 1e6);
        System.out.printf("Serial execution time   : %.3f ms%n", serialNs / 1e6);
        System.out.println("(Thread start-up cost dominates for only 50,000 elements)");
        System.out.println("==========================================");
    }
}
