public class ParallelMaxSearch extends SensorSearchEngine {

    private final int workerCount;
    private double globalMax = -Double.MAX_VALUE;

    public ParallelMaxSearch(double[] sensorData, int startIdx, int endIdx, int workerCount) {
        super(sensorData, startIdx, endIdx);
        this.workerCount = workerCount;
    }

    @Override
    public void processGrid() throws InterruptedException {
        double[] localMax = new double[workerCount];
        Thread[] workers = new Thread[workerCount];
        int total = endIdx - startIdx;
        int chunk = total / workerCount;

        for (int w = 0; w < workerCount; w++) {
            final int id = w;
            final int from = startIdx + w * chunk;
            final int to = (w == workerCount - 1) ? endIdx : from + chunk;

            workers[w] = new Thread(() -> {
                double max = -Double.MAX_VALUE;
                for (int i = from; i < to; i++) {
                    if (sensorData[i] > max) {
                        max = sensorData[i];
                    }
                }
                localMax[id] = max;
                System.out.printf("[MAX-Worker-%d] segment [%d..%d) local peak    = %.2f%n",
                        id + 1, from, to, max);
            }, "MAX-Worker-" + (w + 1));
            workers[w].start();
        }

        for (Thread t : workers) {
            t.join();
        }

        for (double m : localMax) {
            if (m > globalMax) {
                globalMax = m;
            }
        }
    }

    public double getGlobalMax() {
        return globalMax;
    }
}
