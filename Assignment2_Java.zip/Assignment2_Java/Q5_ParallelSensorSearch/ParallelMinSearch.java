public class ParallelMinSearch extends SensorSearchEngine {

    private final int workerCount;
    private double globalMin = Double.MAX_VALUE;

    public ParallelMinSearch(double[] sensorData, int startIdx, int endIdx, int workerCount) {
        super(sensorData, startIdx, endIdx);
        this.workerCount = workerCount;
    }

    @Override
    public void processGrid() throws InterruptedException {
        double[] localMin = new double[workerCount];
        Thread[] workers = new Thread[workerCount];
        int total = endIdx - startIdx;
        int chunk = total / workerCount;

        for (int w = 0; w < workerCount; w++) {
            final int id = w;
            final int from = startIdx + w * chunk;
            final int to = (w == workerCount - 1) ? endIdx : from + chunk;

            workers[w] = new Thread(() -> {
                double min = Double.MAX_VALUE;
                for (int i = from; i < to; i++) {
                    if (sensorData[i] < min) {
                        min = sensorData[i];
                    }
                }
                localMin[id] = min;
                System.out.printf("[MIN-Worker-%d] segment [%d..%d) local minimum = %.2f%n",
                        id + 1, from, to, min);
            }, "MIN-Worker-" + (w + 1));
            workers[w].start();
        }

        for (Thread t : workers) {
            t.join();
        }

        // Reduction of the partial results
        for (double m : localMin) {
            if (m < globalMin) {
                globalMin = m;
            }
        }
    }

    public double getGlobalMin() {
        return globalMin;
    }
}
